// Smart Farm Dashboard JS
// Thêm logic tương tác ở đây sau này