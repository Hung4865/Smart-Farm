{
    'name': 'Smart Farm Management',
    'version': '18.0.1.0.0',
    'category': 'Agriculture',
    'summary': 'Nền tảng quản lý trang trại thông minh',
    'author': 'Farm Management Team',
    'depends': ['base', 'mail', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/dashboard.xml',
        'views/menu.xml',
        'views/gps_views.xml',
        'views/weather_views.xml',
        'views/alert_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}