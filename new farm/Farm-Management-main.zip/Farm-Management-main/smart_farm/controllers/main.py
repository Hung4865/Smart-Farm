from odoo import http
from odoo.http import request
from datetime import datetime
import requests as req_lib


class SmartFarmDashboard(http.Controller):

    @http.route('/smart_farm/dashboard', type='http', auth='user')
    def dashboard(self, **kwargs):
        env = request.env

        gps_records = env['smart.farm.gps'].search(
            [], limit=5, order='timestamp desc'
        )

        weather = None
        try:
            r = req_lib.get(
                "https://api.open-meteo.com/v1/forecast"
                "?latitude=10.82&longitude=106.63"
                "&current_weather=true&hourly=relative_humidity_2m",
                timeout=5,
            )
            if r.status_code == 200:
                data = r.json()
                cw = data['current_weather']
                humidity = data.get('hourly', {}).get('relative_humidity_2m', [75])[0]
                weather = {
                    'temperature': cw['temperature'],
                    'windspeed': cw['windspeed'],
                    'humidity': humidity,
                    'source': 'live',
                }
        except Exception:
            pass

        if not weather:
            latest = env['smart.farm.weather'].search(
                [], limit=1, order='timestamp desc'
            )
            if latest:
                weather = {
                    'temperature': latest.temperature,
                    'windspeed': latest.windspeed,
                    'humidity': latest.humidity,
                    'source': 'db',
                }
            else:
                weather = {
                    'temperature': 31,
                    'windspeed': 12,
                    'humidity': 78,
                    'source': 'mock',
                }

        alerts = env['smart.farm.alert'].search(
            [], limit=6, order='timestamp desc'
        )
        unresolved_count = env['smart.farm.alert'].search_count(
            [('is_resolved', '=', False)]
        )

        values = {
            'gps_records': gps_records,
            'weather': weather,
            'alerts': alerts,
            'unresolved_count': unresolved_count,
            'now': datetime.now(),
        }

        return request.render('smart_farm.dashboard_main', values)